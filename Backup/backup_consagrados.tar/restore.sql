--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE consagrados;
--
-- Name: consagrados; Type: DATABASE; Schema: -; Owner: brian
--

CREATE DATABASE consagrados WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE consagrados OWNER TO brian;

\unrestrict (null)
\connect consagrados
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: AuthProvider; Type: TYPE; Schema: public; Owner: brian
--

CREATE TYPE public."AuthProvider" AS ENUM (
    'LOCAL',
    'AUTH0'
);


ALTER TYPE public."AuthProvider" OWNER TO brian;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: brian
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'REVIEW',
    'PAID'
);


ALTER TYPE public."OrderStatus" OWNER TO brian;

--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: brian
--

CREATE TYPE public."PaymentType" AS ENUM (
    'TRANSFER',
    'MERCADOPAGO',
    'CASH'
);


ALTER TYPE public."PaymentType" OWNER TO brian;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: brian
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPERADMIN',
    'DEVELOPER',
    'ADMIN',
    'EDITOR',
    'COLLABORATOR',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO brian;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Combo; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Combo" (
    id text NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    year integer NOT NULL,
    "minPersons" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "eventId" text NOT NULL
);


ALTER TABLE public."Combo" OWNER TO brian;

--
-- Name: Egreso; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Egreso" (
    id text NOT NULL,
    fecha timestamp(3) without time zone NOT NULL,
    concepto text NOT NULL,
    monto double precision NOT NULL,
    "metodoPago" text NOT NULL,
    notas text,
    year integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Egreso" OWNER TO brian;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    year integer NOT NULL,
    topic text NOT NULL,
    capacity integer NOT NULL,
    "salesStartDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Event" OWNER TO brian;

--
-- Name: Ingreso; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Ingreso" (
    id text NOT NULL,
    fecha timestamp(3) without time zone NOT NULL,
    concepto text NOT NULL,
    monto double precision NOT NULL,
    "metodoPago" text NOT NULL,
    notas text,
    year integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Ingreso" OWNER TO brian;

--
-- Name: Invitee; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Invitee" (
    id text NOT NULL,
    name text NOT NULL,
    cuil text NOT NULL,
    "orderId" text,
    "paymentId" text,
    "attendedDay1" boolean DEFAULT false NOT NULL,
    "attendedDay2" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    email text,
    phone text
);


ALTER TABLE public."Invitee" OWNER TO brian;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    year integer NOT NULL,
    "userId" text,
    "eventId" text NOT NULL,
    total double precision NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "paymentType" public."PaymentType" NOT NULL,
    "externalReference" text,
    "metadataToken" text,
    "preferenceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    cuil text NOT NULL,
    email text NOT NULL,
    phone text
);


ALTER TABLE public."Order" OWNER TO brian;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    year integer NOT NULL,
    "orderId" text NOT NULL,
    amount double precision NOT NULL,
    type public."PaymentType" NOT NULL,
    "externalReference" text,
    "userId" text,
    "payerName" text,
    "payerEmail" text,
    "payerDni" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "payerPhone" text
);


ALTER TABLE public."Payment" OWNER TO brian;

--
-- Name: PreSale; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."PreSale" (
    id text NOT NULL,
    "eventId" text NOT NULL,
    "discountPercent" double precision NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "ticketQuantity" integer NOT NULL,
    year integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."PreSale" OWNER TO brian;

--
-- Name: User; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "auth0Id" text,
    provider public."AuthProvider" DEFAULT 'LOCAL'::public."AuthProvider" NOT NULL,
    dni text NOT NULL,
    name text NOT NULL,
    "givenName" text,
    "familyName" text,
    nickname text,
    email text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    picture text,
    locale text,
    password text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO brian;

--
-- Name: _ComboToOrder; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public."_ComboToOrder" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ComboToOrder" OWNER TO brian;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: brian
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO brian;

--
-- Data for Name: Combo; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Combo" (id, name, price, year, "minPersons", "createdAt", "updatedAt", "deletedAt", "eventId") FROM stdin;
\.
COPY public."Combo" (id, name, price, year, "minPersons", "createdAt", "updatedAt", "deletedAt", "eventId") FROM '$$PATH$$/3495.dat';

--
-- Data for Name: Egreso; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Egreso" (id, fecha, concepto, monto, "metodoPago", notas, year, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Egreso" (id, fecha, concepto, monto, "metodoPago", notas, year, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3502.dat';

--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Event" (id, year, topic, capacity, "salesStartDate", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Event" (id, year, topic, capacity, "salesStartDate", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3494.dat';

--
-- Data for Name: Ingreso; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Ingreso" (id, fecha, concepto, monto, "metodoPago", notas, year, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Ingreso" (id, fecha, concepto, monto, "metodoPago", notas, year, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3501.dat';

--
-- Data for Name: Invitee; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Invitee" (id, name, cuil, "orderId", "paymentId", "attendedDay1", "attendedDay2", "createdAt", "updatedAt", "deletedAt", email, phone) FROM stdin;
\.
COPY public."Invitee" (id, name, cuil, "orderId", "paymentId", "attendedDay1", "attendedDay2", "createdAt", "updatedAt", "deletedAt", email, phone) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Order" (id, year, "userId", "eventId", total, status, "paymentType", "externalReference", "metadataToken", "preferenceId", "createdAt", "updatedAt", "deletedAt", cuil, email, phone) FROM stdin;
\.
COPY public."Order" (id, year, "userId", "eventId", total, status, "paymentType", "externalReference", "metadataToken", "preferenceId", "createdAt", "updatedAt", "deletedAt", cuil, email, phone) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."Payment" (id, year, "orderId", amount, type, "externalReference", "userId", "payerName", "payerEmail", "payerDni", "createdAt", "updatedAt", "deletedAt", "payerPhone") FROM stdin;
\.
COPY public."Payment" (id, year, "orderId", amount, type, "externalReference", "userId", "payerName", "payerEmail", "payerDni", "createdAt", "updatedAt", "deletedAt", "payerPhone") FROM '$$PATH$$/3498.dat';

--
-- Data for Name: PreSale; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."PreSale" (id, "eventId", "discountPercent", "startDate", "ticketQuantity", year, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PreSale" (id, "eventId", "discountPercent", "startDate", "ticketQuantity", year, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3496.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."User" (id, "auth0Id", provider, dni, name, "givenName", "familyName", nickname, email, "emailVerified", picture, locale, password, role, "createdAt", "updatedAt", "lastLogin", "deletedAt") FROM stdin;
\.
COPY public."User" (id, "auth0Id", provider, dni, name, "givenName", "familyName", nickname, email, "emailVerified", picture, locale, password, role, "createdAt", "updatedAt", "lastLogin", "deletedAt") FROM '$$PATH$$/3493.dat';

--
-- Data for Name: _ComboToOrder; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public."_ComboToOrder" ("A", "B") FROM stdin;
\.
COPY public."_ComboToOrder" ("A", "B") FROM '$$PATH$$/3500.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: brian
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3492.dat';

--
-- Name: Combo Combo_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Combo"
    ADD CONSTRAINT "Combo_pkey" PRIMARY KEY (id);


--
-- Name: Egreso Egreso_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Egreso"
    ADD CONSTRAINT "Egreso_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: Ingreso Ingreso_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Ingreso"
    ADD CONSTRAINT "Ingreso_pkey" PRIMARY KEY (id);


--
-- Name: Invitee Invitee_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Invitee"
    ADD CONSTRAINT "Invitee_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: PreSale PreSale_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."PreSale"
    ADD CONSTRAINT "PreSale_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _ComboToOrder _ComboToOrder_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."_ComboToOrder"
    ADD CONSTRAINT "_ComboToOrder_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Combo_name_year_key; Type: INDEX; Schema: public; Owner: brian
--

CREATE UNIQUE INDEX "Combo_name_year_key" ON public."Combo" USING btree (name, year);


--
-- Name: Order_externalReference_key; Type: INDEX; Schema: public; Owner: brian
--

CREATE UNIQUE INDEX "Order_externalReference_key" ON public."Order" USING btree ("externalReference");


--
-- Name: User_auth0Id_key; Type: INDEX; Schema: public; Owner: brian
--

CREATE UNIQUE INDEX "User_auth0Id_key" ON public."User" USING btree ("auth0Id");


--
-- Name: User_dni_key; Type: INDEX; Schema: public; Owner: brian
--

CREATE UNIQUE INDEX "User_dni_key" ON public."User" USING btree (dni);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: brian
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _ComboToOrder_B_index; Type: INDEX; Schema: public; Owner: brian
--

CREATE INDEX "_ComboToOrder_B_index" ON public."_ComboToOrder" USING btree ("B");


--
-- Name: Combo Combo_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Combo"
    ADD CONSTRAINT "Combo_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."Event"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invitee Invitee_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Invitee"
    ADD CONSTRAINT "Invitee_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invitee Invitee_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Invitee"
    ADD CONSTRAINT "Invitee_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."Event"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PreSale PreSale_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."PreSale"
    ADD CONSTRAINT "PreSale_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."Event"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _ComboToOrder _ComboToOrder_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."_ComboToOrder"
    ADD CONSTRAINT "_ComboToOrder_A_fkey" FOREIGN KEY ("A") REFERENCES public."Combo"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ComboToOrder _ComboToOrder_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: brian
--

ALTER TABLE ONLY public."_ComboToOrder"
    ADD CONSTRAINT "_ComboToOrder_B_fkey" FOREIGN KEY ("B") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

